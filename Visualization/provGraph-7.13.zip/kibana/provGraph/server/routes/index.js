"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;

var _get_nodes_data = require("./get_nodes_data");

var _get_edges_data = require("./get_edges_data");

var _get_growed_nodes_data = require("./get_growed_nodes_data");

var _get_growed_edges_data = require("./get_growed_edges_data");

var _get_max_sequence = require("./get_max_sequence");

var _get_min_sequence = require("./get_min_sequence");

function defineRoutes(router) {
  (0, _get_nodes_data.registerGetNodesRoute)(router);
  (0, _get_edges_data.registerGetEdgesRoute)(router);
  (0, _get_growed_nodes_data.registerGetGrowedNodesRoute)(router);
  (0, _get_growed_edges_data.registerGetGrowedEdgesRoute)(router);
  (0, _get_max_sequence.registerGetMaxSequence)(router);
  (0, _get_min_sequence.registerGetMinSequence)(router); // router.get(
  //   {
  //     path: '/api/p_graph/example',
  //     validate: false,
  //   },
  //   async (context, request, response) => {
  //     return response.ok({
  //       body: {
  //         time: new Date().toISOString(),
  //       },
  //     });
  //   }
  // );
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImRlZmluZVJvdXRlcyIsInJvdXRlciJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUVPLFNBQVNBLFlBQVQsQ0FBc0JDLE1BQXRCLEVBQXVDO0FBQzVDLDZDQUFzQkEsTUFBdEI7QUFDQSw2Q0FBc0JBLE1BQXRCO0FBQ0EsMERBQTRCQSxNQUE1QjtBQUNBLDBEQUE0QkEsTUFBNUI7QUFDQSxnREFBdUJBLE1BQXZCO0FBQ0EsZ0RBQXVCQSxNQUF2QixFQU40QyxDQU81QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSVJvdXRlciB9IGZyb20gJy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyByZWdpc3RlckdldE5vZGVzUm91dGUgfSBmcm9tICcuL2dldF9ub2Rlc19kYXRhJztcbmltcG9ydCB7IHJlZ2lzdGVyR2V0RWRnZXNSb3V0ZSB9IGZyb20gJy4vZ2V0X2VkZ2VzX2RhdGEnO1xuaW1wb3J0IHsgcmVnaXN0ZXJHZXRHcm93ZWROb2Rlc1JvdXRlIH0gZnJvbSAnLi9nZXRfZ3Jvd2VkX25vZGVzX2RhdGEnO1xuaW1wb3J0IHsgcmVnaXN0ZXJHZXRHcm93ZWRFZGdlc1JvdXRlIH0gZnJvbSAnLi9nZXRfZ3Jvd2VkX2VkZ2VzX2RhdGEnO1xuaW1wb3J0IHsgcmVnaXN0ZXJHZXRNYXhTZXF1ZW5jZSB9IGZyb20gJy4vZ2V0X21heF9zZXF1ZW5jZSc7XG5pbXBvcnQgeyByZWdpc3RlckdldE1pblNlcXVlbmNlIH0gZnJvbSAnLi9nZXRfbWluX3NlcXVlbmNlJztcblxuZXhwb3J0IGZ1bmN0aW9uIGRlZmluZVJvdXRlcyhyb3V0ZXI6IElSb3V0ZXIpIHtcbiAgcmVnaXN0ZXJHZXROb2Rlc1JvdXRlKHJvdXRlcik7XG4gIHJlZ2lzdGVyR2V0RWRnZXNSb3V0ZShyb3V0ZXIpO1xuICByZWdpc3RlckdldEdyb3dlZE5vZGVzUm91dGUocm91dGVyKTtcbiAgcmVnaXN0ZXJHZXRHcm93ZWRFZGdlc1JvdXRlKHJvdXRlcik7XG4gIHJlZ2lzdGVyR2V0TWF4U2VxdWVuY2Uocm91dGVyKTtcbiAgcmVnaXN0ZXJHZXRNaW5TZXF1ZW5jZShyb3V0ZXIpO1xuICAvLyByb3V0ZXIuZ2V0KFxuICAvLyAgIHtcbiAgLy8gICAgIHBhdGg6ICcvYXBpL3BfZ3JhcGgvZXhhbXBsZScsXG4gIC8vICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gIC8vICAgfSxcbiAgLy8gICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgLy8gICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gIC8vICAgICAgIGJvZHk6IHtcbiAgLy8gICAgICAgICB0aW1lOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gIC8vICAgICAgIH0sXG4gIC8vICAgICB9KTtcbiAgLy8gICB9XG4gIC8vICk7XG59XG4iXX0=